---
layout: post
title: Allorunner AR Launch
---
The world's perhaps first Augmented Reality endless runner is now available on [Google Play](https://play.google.com/store/apps/details?id=com.michaeltroger.allorunnerar).
One sheet of paper - endless fun! 
<iframe width="560" height="315" src="https://www.youtube.com/embed/tMx2ZVE-jY0" frameborder="0" allowfullscreen></iframe>
Go to the [instructions-page](/allorunnerar) for more info.
