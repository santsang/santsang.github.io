---
layout: post
---
This website is powered by [Jekyll](http://jekyllrb.com) and I can use Markdown to author my posts. It is based on [Jonathan McGlone's project](https://github.com/hankquinlan/hankquinlan.github.io/). This website will be used for sharing current projects of mine.
